<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div style="padding: 2rem 0; background-color: #F9FAFB;">
        <div style="max-width: 1280px; margin: 0 auto; padding: 0 1.5rem;">
            
            <!-- Cabeçalho -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="font-size: 2rem; font-weight: bold; color: #333; margin: 0;">
                    Dashboard Administrativo
                </h2>
            </div>

            <!-- Secção de estatísticas -->
            <div style="display: flex; flex-wrap: wrap; gap: 1.5rem; margin-bottom: 2rem;">
                
                <!-- Cartão de Utilizadores -->
                <div style="flex: 1 1 300px;">
                    <div style="background-color: #F9FAFB; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; padding: 1.5rem;">
                        <h5 style="font-size: 1.25rem; font-weight: 600; color: #333; margin-bottom: 1rem;">
                            Utilizadores
                        </h5>
                        <p style="font-size: 2rem; font-weight: bold; margin: 1rem 0;">
                            <?php echo e($stats['users']); ?>

                        </p>
                        <a href="<?php echo e(route('users.index')); ?>" 
                           style="display: inline-block; padding: 0.5rem 1rem; background-color: rgb(36, 104, 250); color: #FFF; text-decoration: none; border-radius: 4px; font-size: 0.875rem;">
                            Gerir Utilizadores
                        </a>
                    </div>
                </div>

                <!-- Cartão de Categorias -->
                <div style="flex: 1 1 300px;">
                    <div style="background-color: #FFF; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; padding: 1.5rem;">
                        <h5 style="font-size: 1.25rem; font-weight: 600; color: #333; margin-bottom: 1rem;">
                            Categorias
                        </h5>
                        <p style="font-size: 2rem; font-weight: bold; margin: 1rem 0;">
                            <?php echo e($stats['categorias']); ?>

                        </p>
                        <a href="<?php echo e(route('categorias.index')); ?>" 
                           style="display: inline-block; padding: 0.5rem 1rem; background-color: rgb(36, 104, 250); color: #FFF; text-decoration: none; border-radius: 4px; font-size: 0.875rem;">
                            Gerir Categorias
                        </a>
                    </div>
                </div>

                <!-- Cartão de Produtos -->
                <div style="flex: 1 1 300px;">
                    <div style="background-color: #FFF; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; padding: 1.5rem;">
                        <h5 style="font-size: 1.25rem; font-weight: 600; color: #333; margin-bottom: 1rem;">
                            Produtos
                        </h5>
                        <p style="font-size: 2rem; font-weight: bold; margin: 1rem 0;">
                            <?php echo e($stats['produtos']); ?>

                        </p>
                        <a href="<?php echo e(route('produtos.index')); ?>" 
                           style="display: inline-block; padding: 0.5rem 1rem; background-color: rgb(36, 104, 250); color: #FFF; text-decoration: none; border-radius: 4px; font-size: 0.875rem;">
                            Gerir Produtos
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/dashboard.blade.php ENDPATH**/ ?>