
<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div style="padding: 2rem 0; background-color: #F9FAFB;">
        <div style="max-width: 1280px; margin: 0 auto; padding: 1rem;">
            <h1 style="font-size: 1.5rem; font-weight: bold; color: #333; margin-bottom: 1rem;">Meus Produtos</h1>

            <?php $__empty_1 = true; $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="background-color: #FFF; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden; display: flex; flex-direction: column; margin-bottom: 1rem;">
                    <!-- Imagem do Produto -->
                    <div style="position: relative;">
                        <img src="<?php echo e(asset('storage/' . $produto->imagem)); ?>"
                            style="width: 100%; height: 12rem; object-fit: cover;"
                            alt="<?php echo e($produto->nome); ?>">
                    </div>

                    <!-- Informações do Produto -->
                    <div style="padding: 1rem;">
                        <h3 style="font-size: 1.125rem; font-weight: bold; color: #333; margin-bottom: 0.5rem;"><?php echo e($produto->nome); ?></h3>
                        <p style="font-size: 0.875rem; color: #6B7280; margin-bottom: 0.5rem;"><?php echo e(Str::limit($produto->descricao, 100)); ?></p>
                        <span style="font-size: 1.25rem; font-weight: bold; color: #2563EB;"><?php echo e(number_format($produto->preco, 2)); ?>€</span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="text-align: center; font-size: 1.25rem; color: #6B7280;">Você ainda não publicou nenhum produto.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/produtos/myproducts.blade.php ENDPATH**/ ?>