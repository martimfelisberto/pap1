<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div style="max-width: 1280px; margin: 0 auto; padding: 2rem 1rem;">
        <h1 style="font-size: 2rem; font-weight: bold; margin-bottom: 2rem;">Meus Favoritos</h1>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 2rem;">
            <?php $__empty_1 = true; $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="background-color: #FFF; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden; display: flex; flex-direction: column; height: 100%;">
                    <div style="position: relative;">
                        <?php if($favorite->produto->imagem): ?>
                            <img src="<?php echo e(asset('storage/' . $favorite->produto->imagem)); ?>" alt="<?php echo e($favorite->produto->titulo); ?>" 
                                style="width: 100%; height: 220px; object-fit: cover;">
                        <?php else: ?>
                            <div style="width: 100%; height: 220px; background-color: #EEE; display: flex; align-items: center; justify-content: center;">
                                <i class="bi bi-image" style="font-size: 2.5rem; color: #CCC;"></i>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($favorite->produto->categoria): ?>
                            <span style="position: absolute; top: 0.75rem; left: 0.75rem; background-color: rgba(4, 23, 85, 0.8); color: white; font-size: 0.75rem; padding: 0.25rem 0.75rem; border-radius: 999px;">
                                <?php echo e($favorite->produto->categoria->nome); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div style="padding: 1.25rem; flex-grow: 1; display: flex; flex-direction: column;">
                        <h3 style="font-size: 1.25rem; font-weight: bold; margin-bottom: 0.5rem;"><?php echo e($favorite->produto->titulo); ?></h3>
                        <p style="color: #6B7280; margin-bottom: 1rem; flex-grow: 1;"><?php echo e(Str::limit($favorite->produto->descricao, 100)); ?></p>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                            <span style="font-size: 1.25rem; font-weight: bold; color: #2563EB;"><?php echo e(number_format($favorite->produto->preco, 2)); ?>€</span>
                            
                            <div style="display: flex; gap: 0.5rem;">
                                
                                
                                <form action="<?php echo e(route('favoritos.toggle')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="produto_id" value="<?php echo e($favorite->produto->id); ?>">
                                    <button type="submit" 
                                        style="padding: 0.5rem 1rem; background-color: #FEE2E2; color: #DC2626; border: none; border-radius: 8px; cursor: pointer;">
                                        <i class="bi bi-heart-fill"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div style="grid-column: 1 / -1;">
                    <div style="background-color: #F3F4F6; padding: 3rem; border-radius: 12px; text-align: center;">
                        <i class="bi bi-heart" style="font-size: 3.5rem; color: #9CA3AF; margin-bottom: 1.5rem;"></i>
                        <h3 style="font-size: 1.75rem; margin-bottom: 1rem;">Nenhum favorito encontrado</h3>
                        <p style="color: #6B7280; margin-bottom: 1.5rem;">Você ainda não adicionou nenhum produto aos favoritos.</p>
                        <a href="<?php echo e(route('produtos.index')); ?>" 
                           style="padding: 0.75rem 1.5rem; background-color: rgb(4, 23, 85); color: white; border-radius: 8px; text-decoration: none; display: inline-block;">
                            Explorar Produtos
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <div style="margin-top: 2rem;">
            <?php echo e($favorites->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?><?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/favoritos/index.blade.php ENDPATH**/ ?>