<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div style="max-width: 600px; margin: 0 auto; padding: 2rem 1rem;">
    <!-- Cabeçalho -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
      <h1 style="font-size: 1.75rem; font-weight: 600; color: #333; margin: 0;">Editar Utilizador</h1>
      <a href="<?php echo e(route('users.index')); ?>" 
         style="padding: 0.5rem 1rem; background-color:#6B7280; color: #FFF; border-radius: 4px; text-decoration: none; font-size: 0.875rem; display: inline-flex; align-items: center;">
        <i class="bi bi-arrow-left" style="margin-right: 0.5rem;"></i> Voltar
      </a>
    </div>

    <!-- Mensagem de Feedback -->
    <?php if(session('success')): ?>
      <div style="padding: 0.75rem; background-color: #DCFCE7; border: 1px solid #16A34A; border-radius: 4px; margin-bottom: 1rem; color: #16A34A; position: relative;">
        <?php echo e(session('success')); ?>

        <button onclick="this.parentElement.style.display = 'none'" 
                style="background: none; border: none; position: absolute; top: 0.25rem; right: 0.5rem; font-size: 1.25rem; line-height: 1; cursor: pointer;">&times;</button>
      </div>
    <?php endif; ?>

    <!-- Formulário de Edição -->
    <div style="background-color: #FFF; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); padding: 2rem;">
      <form action="<?php echo e(route('users.update', $user)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <!-- Campo Nome -->
        <div style="margin-bottom: 1.5rem;">
          <label for="name" style="display: block; font-size: 1rem; font-weight: 500; margin-bottom: 0.5rem;">Nome</label>
          <input type="text" id="name" name="name"
                 style="width: 100%; padding: 0.75rem; border: 1px solid #CCC; border-radius: 4px; font-size: 1rem;"
                 class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 value="<?php echo e(old('name', $user->name)); ?>" required>
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: #d9534f; font-size: 0.875rem; margin-top: 0.5rem;"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Campo Email -->
        <div style="margin-bottom: 1.5rem;">
          <label for="email" style="display: block; font-size: 1rem; font-weight: 500; margin-bottom: 0.5rem;">Email</label>
          <input type="email" id="email" name="email"
                 style="width: 100%; padding: 0.75rem; border: 1px solid #CCC; border-radius: 4px; font-size: 1rem;"
                 class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 value="<?php echo e(old('email', $user->email)); ?>" required>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: #d9534f; font-size: 0.875rem; margin-top: 0.5rem;"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Campo Administrador -->
        <div style="margin-bottom: 1.5rem;">
          <label for="is_admin" style="display: block; font-size: 1rem; font-weight: 500; margin-bottom: 0.5rem;">Administrador</label>
          <select id="is_admin" name="is_admin"
                  style="width: 100%; padding: 0.75rem; border: 1px solid #CCC; border-radius: 4px; font-size: 1rem;">
            <option value="1" <?php echo e($user->is_admin ? 'selected' : ''); ?>>Sim</option>
            <option value="0" <?php echo e(!$user->is_admin ? 'selected' : ''); ?>>Não</option>
          </select>
          <?php $__errorArgs = ['is_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: #d9534f; font-size: 0.875rem; margin-top: 0.5rem;"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Botão de Envio -->
        <div style="text-align: right;">
          <button type="submit" 
                  style="padding: 0.75rem 1.5rem; background-color: #2563EB; color: #FFF; border: none; border-radius: 4px; font-size: 1rem; cursor: pointer;">
            <i class="bi bi-save" style="margin-right: 0.5rem;"></i> Salvar Alterações
          </button>
        </div>
      </form>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>