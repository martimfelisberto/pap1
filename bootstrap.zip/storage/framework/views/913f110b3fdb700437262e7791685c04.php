<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4 py-8">
        <!-- Voltar para listagem -->
        <div class="mb-6">
            <a href="<?php echo e(route('produtos.index')); ?>" class="text-blue-600 hover:underline flex items-center">
                <i class="bi bi-arrow-left mr-2"></i> Voltar para listagem
            </a>
        </div>

        <!-- Detalhes do Produto -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <div class="md:flex">
                <!-- Imagem do Produto -->
                <div class="md:w-1/2 relative">
                    <img src="<?php echo e(asset('storage/' . $produto->imagem)); ?>" 
                         alt="<?php echo e($produto->nome); ?>" 
                         class="w-full h-full object-cover">
                    
                    <!-- Badges -->
                    <div class="absolute top-4 right-4">
                        <span class="bg-blue-100 text-blue-700 text-sm font-medium px-3 py-1 rounded-full">
                            <i class="bi bi-tag-fill mr-1"></i><?php echo e($produto->marca); ?>

                        </span>
                    </div>
                    
                    <?php if($produto->estado): ?>
                        <?php
                            $badgeStyles = [
                                'Novo' => 'bg-green-100 text-green-700',
                                'Semi-novo' => 'bg-yellow-100 text-yellow-700',
                                'Usado' => 'bg-gray-100 text-gray-700'
                            ];
                            $style = $badgeStyles[$produto->estado] ?? 'bg-gray-100 text-gray-700';
                        ?>
                        <div class="absolute bottom-4 left-4">
                            <span class="<?php echo e($style); ?> text-sm font-medium px-3 py-1 rounded-full">
                                <?php echo e($produto->estado); ?>

                            </span>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Informações do Produto -->
                <div class="md:w-1/2 p-8">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-900"><?php echo e($produto->nome); ?></h1>
                            <p class="text-lg text-gray-500"><?php echo e($produto->marca); ?></p>
                        </div>
                        <span class="text-2xl font-bold text-blue-600">
                            <?php echo e(number_format($produto->preco, 2)); ?>€
                        </span>
                    </div>
                    
                    <div class="mb-6 pb-6 border-b border-gray-200">
                        <div class="flex items-center text-sm text-gray-600 mb-4">
                            <i class="bi bi-person-fill mr-2"></i> 
                            Vendedor: <strong class="ml-1"><?php echo e($produto->user?->name ?? 'Utilizador desconhecido'); ?></strong>
                        </div>
                        
                        <div class="flex items-center mb-4">
                            <span class="bg-gray-100 text-gray-700 text-sm font-medium px-3 py-1 rounded-full mr-2">
                                <i class="bi bi-collection-fill mr-1"></i><?php echo e($produto->categoria?->titulo ?? 'Sem categoria'); ?>

                            </span>
                            <span class="bg-gray-100 text-gray-700 text-sm font-medium px-3 py-1 rounded-full">
                                <i class="bi bi-gender-ambiguous mr-1"></i><?php echo e(ucfirst($produto->genero)); ?>

                            </span>
                        </div>
                        
                        <?php if($produto->tamanho): ?>
                            <div class="flex items-center mb-4">
                                <span class="text-gray-600">
                                    <i class="bi bi-rulers mr-1"></i>Tamanho: <strong><?php echo e($produto->tamanho); ?></strong>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-8">
                        <h3 class="text-lg font-semibold text-gray-900 mb-2">Descrição</h3>
                        <p class="text-gray-600"><?php echo e($produto->descricao); ?></p>
                    </div>
                    
                    <!-- Botões de ação -->
                    <div class="flex gap-4">
                        <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition">
                            <i class="bi bi-cart-plus mr-2"></i> Adicionar ao carrinho
                        </button>
                        <button class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium p-3 rounded-lg transition">
                            <i class="bi bi-heart"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Produtos Relacionados (opcional) -->
        <?php if(isset($produtosRelacionados) && $produtosRelacionados->count() > 0): ?>
            <div class="mt-16">
                <h2 class="text-2xl font-bold text-gray-900 mb-6">Produtos Relacionados</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <?php $__currentLoopData = $produtosRelacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produtoRelacionado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Card de produto relacionado -->
                        <div class="bg-white rounded-lg shadow overflow-hidden">
                            <!-- Conteúdo do card -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?><?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/produtos/show.blade.php ENDPATH**/ ?>