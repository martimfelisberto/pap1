<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <!-- Container: fundo único e centralização vertical/horizontal com padding superior reduzido -->
  <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; background-color: #F9FAFB; padding: 0.5rem 2rem;">
    
    <!-- Card central: fundo branco, sombra suave e bordas arredondadas -->
    <div style="max-width: 800px; width: 100%; background-color: #F9FAFB; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; padding: 1.5rem; margin: 1rem;">
      
      <!-- Cabeçalho -->
      <div style="text-align: center; margin-bottom: 1rem;">
        <h1 style="font-size: 1.875rem; font-weight: 600; color: #333;">Contacte-nos</h1>
        <p style="margin-top: 0.5rem; font-size: 0.875rem; color: #6c757d;">
          Tem alguma dúvida ou problema? Preencha o formulário abaixo e a nossa equipa entrará em contacto o mais brevemente possível.
        </p>
      </div>

      <!-- Mensagem de sucesso -->
      <?php if(session('success')): ?>
        <div style="background-color: #d1e7dd; border: 1px solid #badbcc; color: #0f5132; padding: 0.75rem; border-radius: 4px; text-align: center;" role="alert">
          <p><?php echo e(session('success')); ?></p>
        </div>
      <?php endif; ?>

      <!-- Formulário de contacto -->
      <form action="<?php echo e(route('contactos.store')); ?>" method="POST" style="display: flex; flex-direction: column; gap: 0.75rem;">
        <?php echo csrf_field(); ?>

        <!-- Campo Nome -->
        <div>
          <label for="nome" style="display: block; font-size: 0.875rem; font-weight: 500; color: #333; margin-bottom: 0.5rem;">Nome *</label>
          <input type="text" name="nome" id="nome" value="<?php echo e(old('nome')); ?>" required
                 style="width: 100%; padding: 0.75rem 1rem; border: 1px solid #ccc; border-radius: 4px; outline: none;">
          <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Campo Email -->
        <div>
          <label for="email" style="display: block; font-size: 0.875rem; font-weight: 500; color: #333; margin-bottom: 0.5rem;">Email *</label>
          <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required
                 style="width: 100%; padding: 0.75rem 1rem; border: 1px solid #ccc; border-radius: 4px; outline: none;">
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Campo Telefone (opcional) -->
        <div>
          <label for="telefone" style="display: block; font-size: 0.875rem; font-weight: 500; color: #333; margin-bottom: 0.5rem;">Telefone (opcional)</label>
          <input type="tel" name="telefone" id="telefone" value="<?php echo e(old('telefone')); ?>"
                 style="width: 100%; padding: 0.75rem 1rem; border: 1px solid #ccc; border-radius: 4px; outline: none;">
          <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Campo Mensagem -->
        <div>
          <label for="mensagem" style="display: block; font-size: 0.875rem; font-weight: 500; color: #333; margin-bottom: 0.5rem;">Mensagem *</label>
          <textarea name="mensagem" id="mensagem" rows="5" required
                    style="width: 100%; padding: 0.75rem 1rem; border: 1px solid #ccc; border-radius: 4px; outline: none;"><?php echo e(old('mensagem')); ?></textarea>
          <?php $__errorArgs = ['mensagem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Botão de envio -->
        <div style="text-align: center;">
          <button type="submit"
                  style="width: 100%; padding: 0.75rem 1rem; background-color: rgb(4, 23, 85); color: #FFF; font-weight: 600; border: none; border-radius: 4px; cursor: pointer;">
            Enviar mensagem
          </button>
        </div>
      </form>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/contactos/index.blade.php ENDPATH**/ ?>