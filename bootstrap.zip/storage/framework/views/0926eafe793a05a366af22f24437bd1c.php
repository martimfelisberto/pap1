<?php
?>
<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container py-5" style="max-width: 1280px; margin: 0 auto; padding: 2rem 1rem;">
        <h4 class="mb-4" style="font-size: 1.75rem; font-weight: 600; color: #333;">O teu Carrinho de Compras</h4>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" style="border-radius: 4px;">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(count($carrinho) > 0): ?>
        <div class="table-responsive" style="background-color: #FFF; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden;">
            <table class="table table-hover" style="width: 100%; border-collapse: collapse;">
                <thead class="table-light" style="background-color: #F3F4F6; text-align: left;">
                    <tr>
                        <th style="padding: 0.75rem; border-bottom: 2px solid #E5E7EB;">Produto</th>
                        <th style="padding: 0.75rem; border-bottom: 2px solid #E5E7EB;">Preço Unitário</th>
                        <th style="padding: 0.75rem; border-bottom: 2px solid #E5E7EB;">Quantidade</th>
                        <th style="padding: 0.75rem; border-bottom: 2px solid #E5E7EB;">Subtotal</th>
                        <th style="padding: 0.75rem; border-bottom: 2px solid #E5E7EB;">Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = session('carrinho', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-bottom: 1px solid #E5E7EB;">
                        <td style="padding: 0.75rem;">
                            <div style="display: flex; align-items: center;">
                                <?php if(isset($item['imagem']) && $item['imagem']): ?>
                                    <img src="<?php echo e(asset('storage/' . $item['imagem'])); ?>" alt="<?php echo e($item['nome']); ?>" style="width: 80px; height: 80px; object-fit: cover; margin-right: 0.75rem; border-radius: 4px;">
                                <?php endif; ?>
                                <div>
                                    <h5 style="margin: 0 0 0.25rem 0;"><?php echo e($item['nome']); ?></h5>
                                    <?php if(isset($item['marca'])): ?>
                                        <small style="color: #6B7280;">Marca: <?php echo e($item['marca']); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td style="padding: 0.75rem;">EUR€ <?php echo e(number_format($item['preco'], 2, ',', '.')); ?></td>
                        <td style="padding: 0.75rem;">
                            <form action="<?php echo e(route('carrinho.atualizar', $id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <input type="number" name="quantidade" value="<?php echo e($item['quantidade']); ?>" min="1" 
                                       class="form-control form-control-sm" 
                                       style="width: 70px; display: inline-block;" 
                                       onchange="this.form.submit()">
                            </form>
                        </td>
                        <td style="padding: 0.75rem;">EUR€ <?php echo e(number_format($item['preco'] * $item['quantidade'], 2, ',', '.')); ?></td>
                        <td style="padding: 0.75rem;">
                            <form action="<?php echo e(route('carrinho.remover', $id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger" style="padding: 0.25rem 0.5rem; border-radius: 4px;" title="Remover do carrinho">
                                    <i class="bi bi-cart-x"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot class="table-group-divider" style="background-color: #F3F4F6;">
                    <tr>
                        <td colspan="3" class="text-end fw-bold" style="padding: 0.75rem;">Total:</td>
                        <td colspan="2" class="fw-bold" style="padding: 0.75rem;">EUR€ <?php echo e(number_format($total, 2, ',', '.')); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="d-flex justify-content-between mt-4">
            <a href="<?php echo e(route('produtos.index')); ?>" class="btn btn-outline-secondary" style="padding: 0.5rem 1rem; color:#FFF; background-color:rgb(4, 23, 85); border-radius: 4px;">
                <i class="bi bi-arrow-left"></i> Continuar a comprar
            </a>

            <div>
                <form action="<?php echo e(route('carrinho.limpar')); ?>" method="POST" class="d-inline me-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-outline-danger" style="padding: 0.5rem 1rem; border-radius: 4px;">
                        <i class="bi bi-cart-x"></i> Limpar Carrinho
                    </button>
                </form>

                <!-- Botão Finalizar Compra -->
                <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-primary" style="padding: 0.5rem 1rem; background-color:rgb(4, 23, 85); border-radius: 4px;">
                    <i class="bi bi-bag-check"></i> Finalizar Compra
                </a>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-info" style="margin-bottom: 22rem; border-radius: 4px;">
            <i class="bi bi-info-circle"></i> O teu carrinho está vazio.
            <a href="http://reshoppingpap.test/" class="alert-link">Voltar às compras</a>.
        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/carrinho/index.blade.php ENDPATH**/ ?>