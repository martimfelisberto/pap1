<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div style="padding: 2rem 0; background-color: #F9FAFB;">
        <div style="max-width: 1280px; margin: 0 auto; padding: 1rem;">
            <!-- Cabeçalho -->
            <div style="margin-bottom: 1.5rem;">
                <h2 style="font-size: 2rem; font-weight: bold; color: #333; margin: 0;">
                    Editar Produto
                </h2>
                 </div>

            <!-- Formulário de Edição -->
            <form action="<?php echo e(route('produtos.update', $produto)); ?>" method="POST" enctype="multipart/form-data"
                style="background-color: #FFF; padding: 1.5rem; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Nome do Produto -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="nome" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Nome do Produto</label>
                    <input type="text" id="nome" name="nome" value="<?php echo e(old('nome', $produto->nome)); ?>"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;" required>
                </div>

                <!-- Descrição -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="descricao" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Descrição</label>
                    <textarea id="descricao" name="descricao" rows="4"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;"><?php echo e(old('descricao', $produto->descricao)); ?></textarea>
                </div>

                <!-- Preço -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="preco" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Preço (€)</label>
                    <input type="number" id="preco" name="preco" value="<?php echo e(old('preco', $produto->preco)); ?>" step="0.01"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;" required>
                </div>

                <!-- Categoria -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="categoria" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Categoria</label>
                    <select id="categoria" name="categoria_id"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;" required>
                        <option value="">Selecione uma categoria</option>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria->id); ?>" <?php echo e($produto->categoria_id == $categoria->id ? 'selected' : ''); ?>>
                                <?php echo e($categoria->titulo); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Marca -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="marca" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Marca</label>
                    <input type="text" id="marca" name="marca" value="<?php echo e(old('marca', $produto->marca)); ?>"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;">
                </div>

                <!-- Tamanho -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="tamanho" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Tamanho</label>
                    <input type="text" id="tamanho" name="tamanho" value="<?php echo e(old('tamanho', $produto->tamanho)); ?>"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;">
                </div>

                <!-- Estado -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="estado" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Estado</label>
                    <select id="estado" name="estado"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;">
                        <option value="">Selecione o estado</option>
                        <option value="Novo" <?php echo e($produto->estado == 'Novo' ? 'selected' : ''); ?>>Novo</option>
                        <option value="Semi-novo" <?php echo e($produto->estado == 'Semi-novo' ? 'selected' : ''); ?>>Semi-novo</option>
                        <option value="Usado" <?php echo e($produto->estado == 'Usado' ? 'selected' : ''); ?>>Usado</option>
                    </select>
                </div>

                <!-- Imagem -->
                <div style="margin-bottom: 1.5rem;">
                    <label for="imagem" style="font-size: 0.875rem; color: #333; display: block; margin-bottom: 0.5rem;">Imagem</label>
                    <input type="file" id="imagem" name="imagem"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px;">
                    <?php if($produto->imagem): ?>
                        <div style="margin-top: 0.5rem;">
                            <img src="<?php echo e(asset('storage/' . $produto->imagem)); ?>" alt="<?php echo e($produto->nome); ?>"
                                style="width: 100px; height: auto; border-radius: 8px;">
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Botões -->
                <div style="display: flex; justify-content: flex-end; gap: 1rem;">
                    <a href="<?php echo e(route('produtos.index')); ?>"
                        style="padding: 0.75rem 1.5rem; background-color: #F3F4F6; color: #374151; border: none; border-radius: 8px; text-decoration: none; text-align: center;">
                        Cancelar
                    </a>
                    <button type="submit"
                        style="padding: 0.75rem 1.5rem; background-color: #2563EB; color: #FFF; border: none; border-radius: 8px; cursor: pointer;">
                        Salvar Alterações
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?><?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/produtos/edit.blade.php ENDPATH**/ ?>