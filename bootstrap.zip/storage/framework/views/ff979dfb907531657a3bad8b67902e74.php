<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Header de Perfil (Display) -->
   
                

                <!-- Seções de Atualização do Perfil (sem repetir a função de alteração da foto) -->
                <div style="padding: 2rem 0; background-color: #F9FAFB;">
                    <div style="max-width: 1280px; margin: 0 auto; padding: 0 1.5rem; display: flex; flex-direction: column; gap: 2rem;">

                        <!-- Seções de Atualização do Perfil -->
                        <div style="padding: 3rem 0; background-color: #F9FAFB;">
                            <div style="max-width: 1280px; margin: 0 auto; padding: 0 1rem;">
                                <!-- Profile Photo Section -->
                                <div style="background-color: #FFF; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; padding: 1.5rem; margin-bottom: 1.5rem;">
                                    <!-- Member since text -->

                                    <h2 style="font-size: 1.5rem; font-weight: 600; color: #333; margin-bottom: 1rem;">Foto de Perfil</h2>
                                    <form action="<?php echo e(route('profile.update-photo')); ?>" method="POST" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 1rem;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <div style="display: flex; align-items: center; gap: 1.5rem;">
                                            <!-- Current Photo -->
                                            <div style="position: relative;">
                                                <?php if($user->profile_photo): ?>
                                                <div style="width: 96px; height: 96px; border-radius: 50%; border: 4px solid #cce5ff; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden;">
                                                    <img src="<?php echo e(asset('storage/' . $user->profile_photo)); ?>"
                                                        alt="Profile photo"
                                                        style="width: 100%; height: 100%; object-fit: cover;">
                                                </div>
                                                <?php else: ?>
                                                <div style="width: 96px; height: 96px; border-radius: 50%; 
                                            background: linear-gradient(to right, #3b82f6, rgb(4, 23, 85)); 
                                            border: 4px solid #cce5ff; box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
                                            display: flex; align-items: center; justify-content: center;">
                                                    <span style="font-size: 1.5rem; font-weight: bold; color: #FFF;"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></span>
                                                </div>
                                                <?php endif; ?>
                                            </div>

                                            <!-- Upload New Photo -->
                                            <div style="flex: 1;">
                                                <input type="file"
                                                    name="profile_photo"
                                                    id="profile_photo"
                                                    accept="image/*"
                                                    style="width: 100%; padding: 0.5rem; font-size: 0.875rem; border: 1px solid #ccc; border-radius: 4px;">
                                                <p style="margin-top: 0.5rem; font-size: 0.875rem; color: #6c757d;">PNG, JPG até 2MB</p>
                                            </div>
                                        </div>
                                        <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p style="color: #e63946; font-size: 0.875rem;"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <div style="display: flex; justify-content: flex-end;">
                                            <button type="submit" style="padding: 0.5rem 1rem; background-color: rgb(4, 23, 85); color: #FFF; border: none; border-radius: 4px; font-size: 0.875rem; cursor: pointer;">
                                                Atualizar Foto
                                            </button>
                                        </div>
                                    </form>
                                </div>


                                <!-- Informações do Perfil -->
                                <div style="background-color: #FFF; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; padding: 1.5rem; margin-bottom: 2rem;">
                                    <h2 style="font-size: 1.5rem; font-weight: 600; color: #333; margin-bottom: 1rem;">Informações do Perfil</h2>
                                    <form action="<?php echo e(route('profile.update')); ?>" method="POST" style="display: flex; flex-direction: column; gap: 1rem;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <div>
                                            <label for="name" style="display: block; font-size: 0.875rem; color: #333; margin-bottom: 0.5rem;">Nome</label>
                                            <input type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>"
                                                style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div>
                                            <label for="email" style="display: block; font-size: 0.875rem; color: #333; margin-bottom: 0.5rem;">Email</label>
                                            <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>"
                                                style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div style="display: flex; justify-content: flex-end;">
                                            <button type="submit" style="padding: 0.5rem 1rem; background-color: rgb(4, 23, 85); color: #FFF; border: none; border-radius: 4px; font-size: 0.875rem; cursor: pointer;">
                                                Atualizar Informações
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                <!-- Alterar Password -->
                                <div style="background-color: #FFF; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; padding: 1.5rem; margin-bottom: 2rem;">
                                    <h2 style="font-size: 1.5rem; font-weight: 600; color: #333; margin-bottom: 1rem;">Alterar Password</h2>
                                    <form action="<?php echo e(route('profile.password')); ?>" method="POST" style="display: flex; flex-direction: column; gap: 1rem;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div>
                                            <label for="current_password" style="display: block; font-size: 0.875rem; color: #333; margin-bottom: 0.5rem;">Password Atual</label>
                                            <input type="password"
                                                name="current_password"
                                                id="current_password"
                                                style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
                                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <!-- New Password -->
                                        <div>
                                            <label for="password" style="display: block; font-size: 0.875rem; color: #333; margin-bottom: 0.5rem;">Nova Password</label>
                                            <input type="password"
                                                name="password"
                                                id="password"
                                                style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p style="color: #e63946; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <!-- Confirm New Password -->
                                        <div>
                                            <label for="password_confirmation" style="display: block; font-size: 0.875rem; color: #333; margin-bottom: 0.5rem;">Confirmar Nova Password</label>
                                            <input type="password" name="password_confirmation" id="password_confirmation"
                                                style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
                                        </div>
                                        <div style="display: flex; justify-content: flex-end;">
                                            <button type="submit" style="padding: 0.5rem 1rem; background-color: rgb(4, 23, 85); color: #FFF; border: none; border-radius: 4px; font-size: 0.875rem; cursor: pointer;">
                                                Atualizar Password
                                            </button>
                                        </div>
                                    </form>
                                </div>

                                <!-- Row com 3 cols para Produtos, Favoritos e Vendas -->
                                <div style="display: flex; justify-content: space-between;">
                                    <!-- Coluna 1: Produtos -->
                                    <div style="flex: 1; text-align: center; margin: 0 0.5rem;">
                                        <div style="padding: 1rem; background-color: #FFF; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.05);">
                                            <i class="bi bi-bag" style="color: rgb(4, 23, 85); font-size: 1.5rem;"></i>
                                            <div style="font-size: 1.25rem; font-weight: bold; margin-top: 0.5rem;">
                                                <?php echo e(optional($user->produtos)->count() ?? 0); ?>

                                            </div>
                                            <div style="color: #666;">Produtos</div>
                                        </div>
                                    </div>
                                    <!-- Coluna 2: Favoritos -->
                                    <div style="flex: 1; text-align: center; margin: 0 0.5rem;">
                                        <div style="padding: 1rem; background-color: #FFF; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.05);">
                                            <i class="bi bi-heart-fill" style="color: #d9534f; font-size: 1.5rem;"></i>
                                            <div style="font-size: 1.25rem; font-weight: bold; margin-top: 0.5rem;">
                                                <?php echo e(optional($user->favoriteProdutos)->count() ?? 0); ?>

                                            </div>
                                            <div style="color: #666;">Favoritos</div>
                                        </div>
                                    </div>
                                    <!-- Coluna 3: Vendas -->
                                    <di style="flex: 1; text-align: center; margin: 0 0.5rem;">
                                        <div style="padding: 1rem; background-color: #FFF; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.05);">
                                            <i class="bi bi-cart-check" style="color: #5cb85c; font-size: 1.5rem;"></i>
                                            <div style="font-size: 1.25rem; font-weight: bold; margin-top: 0.5rem;">
                                                <?php echo e(optional($user->vendas)->count() ?? 0); ?>

                                            </div>
                                            <div style="color: #666;">Vendas</div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>


          

    <!-- Script para preview da imagem (caso implemente atualização via outro componente) -->
    <?php $__env->startPush('scripts'); ?>
    <script>
        // Caso seja necessário prever a nova imagem de perfil (exemplo para outro input)
        document.getElementById('profile_photo')?.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.querySelector('[style*="border-radius: 50%"] img');
                    if (img) {
                        img.src = e.target.result;
                    }
                }
                reader.readAsDataURL(e.target.files[0]);
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            // Tab functionality
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            tabButtons.forEach(button => {
                button.addEventListener('click', () => {
                    // Remove active classes
                    tabButtons.forEach(btn => {
                        btn.classList.remove('active');
                        btn.classList.remove('text-warning');
                        btn.classList.remove('border-warning');
                        btn.classList.add('text-gray-500');
                        btn.classList.add('border-transparent');
                    });

                    // Hide all tab contents
                    tabContents.forEach(content => {
                        content.classList.add('hidden');
                    });

                    // Show active tab
                    button.classList.add('active');
                    button.classList.add('text-warning');
                    button.classList.add('border-warning');
                    button.classList.remove('text-gray-500');
                    button.classList.remove('border-transparent');

                    const targetId = button.dataset.target;
                    document.getElementById(targetId).classList.remove('hidden');
                });
            });

            // Profile photo preview
            const photoInput = document.getElementById('profile_photo_upload');
            const photoPreview = document.querySelector('.profile-photo-preview');

            if (photoInput) {
                photoInput.addEventListener('change', function(e) {
                    if (this.files && this.files[0]) {
                        const reader = new FileReader();

                        reader.onload = function(e) {
                            if (photoPreview) {
                                photoPreview.style.backgroundImage = `url('${e.target.result}')`;
                            }
                        }

                        reader.readAsDataURL(this.files[0]);
                    }
                });
            }

            // Animation for cards
            const animateCards = () => {
                const cards = document.querySelectorAll('.card-animate');
                cards.forEach(card => {
                    const rect = card.getBoundingClientRect();
                    const isVisible = (rect.top >= 0 && rect.bottom <= window.innerHeight);

                    if (isVisible) {
                        card.classList.add('animate-fade-in');
                    }
                });
            };

            // Initial animation check
            animateCards();

            // Animate on scroll
            window.addEventListener('scroll', animateCards);
        });
    </script>
    <?php $__env->stopPush(); ?>


    <!-- Add this in the head section or in your layout file -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Open+Sans:wght@400;500;600&display=swap" rel="stylesheet">
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?><?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/profile/edit.blade.php ENDPATH**/ ?>