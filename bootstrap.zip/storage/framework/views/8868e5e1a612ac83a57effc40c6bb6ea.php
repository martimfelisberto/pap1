<?php if (isset($component)) { $__componentOriginal43d0157cd0e4489a7071d7d85ee34682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682 = $attributes; } ?>
<?php $component = App\View\Components\KairaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kaira-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KairaLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">
                <?php echo e(ucfirst($categoria)); ?> <?php echo e(ucfirst($genero)); ?>

            </h1>
            <p class="text-gray-600">
                Explore nossa coleção de <?php echo e($categoria); ?> para <?php echo e($genero); ?>

            </p>
        </div>
 <!-- Filters -->
 <div class="bg-white rounded-2xl shadow-sm p-6 mb-8">
        <form method="GET" action="<?php echo e(route('produtos.categoria', ['categoria' => $categoria, 'genero' => $genero])); ?>" 
              class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            
            <!-- Price Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Preço</label>
                <div class="mt-1 flex gap-2">
                    <input type="number" name="preco_min" placeholder="Min" 
                           class="w-full rounded-xl border-gray-300" 
                           value="<?php echo e(request('preco_min')); ?>">
                    <input type="number" name="preco_max" placeholder="Max" 
                           class="w-full rounded-xl border-gray-300" 
                           value="<?php echo e(request('preco_max')); ?>">
                </div>
            </div>

            <!-- Brand Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Marca</label>
                <select name="marca" class="mt-1 w-full rounded-xl border-gray-300">
                    <option value="">Todas as marcas</option>
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($marca); ?>" <?php echo e(request('marca') == $marca ? 'selected' : ''); ?>>
                            <?php echo e($marca); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Condition Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Estado</label>
                <select name="estado" class="mt-1 w-full rounded-xl border-gray-300">
                    <option value="">Todos os estados</option>
                    <option value="novo" <?php echo e(request('estado') == 'novo' ? 'selected' : ''); ?>>Novo</option>
                    <option value="usado" <?php echo e(request('estado') == 'usado' ? 'selected' : ''); ?>>Usado</option>
                    <option value="semi-novo" <?php echo e(request('estado') == 'semi-novo' ? 'selected' : ''); ?>>Semi-novo</option>
                </select>
            </div>

            <!-- Size Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Tamanho</label>
                <select name="tamanho" class="mt-1 w-full rounded-xl border-gray-300">
                    <option value="">Todos os tamanhos</option>
                    <?php if($categoria === 'sapatilhas'): ?>
                        <?php for($i = 35; $i <= 46; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('tamanho') == $i ? 'selected' : ''); ?>>
                                <?php echo e($i); ?>

                            </option>
                        <?php endfor; ?>
                    <?php else: ?>
                        <?php $__currentLoopData = ['XS', 'S', 'M', 'L', 'XL']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tamanho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tamanho); ?>" <?php echo e(request('tamanho') == $tamanho ? 'selected' : ''); ?>>
                                <?php echo e($tamanho); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>

            <!-- Apply Filters Button -->
            <div class="md:col-span-3 lg:col-span-4 flex justify-end mt-4">
                <button type="submit" class="bg-blue-600 text-white px-3 py-1.5 text-sm rounded-xl hover:bg-blue-700 transition-colors duration-200">
                    <i class="bi bi-funnel mr-2"></i>Aplicar Filtros
                </button>
            </div>
        </form>
    </div>

    <!-- Products Grid -->
    <?php if($produtos->count() > 0): ?>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                    <img src="<?php echo e(asset('storage/' . $produto->imagem)); ?>" 
                         alt="<?php echo e($produto->nome); ?>"
                         class="w-full h-48 object-cover">
                    
                    <div class="p-4">
                        <h3 class="text-lg font-semibold text-gray-900"><?php echo e($produto->nome); ?></h3>
                        <p class="text-gray-600 text-sm mb-2"><?php echo e($produto->marca); ?></p>
                        <div class="flex justify-between items-center">
                            <span class="text-blue-600 font-bold"><?php echo e(number_format($produto->preco, 2)); ?>€</span>
                            <span class="text-sm text-gray-500"><?php echo e(ucfirst($produto->estado)); ?></span>
                        </div>
                        
                        <div class="mt-4 flex gap-2">
                            <a href="<?php echo e(route('produtos.show', $produto)); ?>" 
                               class="flex-1 bg-blue-600 text-white text-center py-2 rounded-xl hover:bg-blue-700 transition-colors duration-200">
                                Ver Detalhes
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="mt-8">
            <?php echo e($produtos->links()); ?>

        </div>
    <?php else: ?>
        <div class="text-center py-12 bg-white rounded-2xl shadow-sm">
            <div class="text-gray-500">
                <i class="bi bi-box text-4xl mb-4"></i>
                <p class="text-xl">Nenhum produto encontrado</p>
                <p class="text-sm mt-2">Tente ajustar os filtros ou volte mais tarde</p>
            </div>
        </div>
    <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $attributes = $__attributesOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__attributesOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682)): ?>
<?php $component = $__componentOriginal43d0157cd0e4489a7071d7d85ee34682; ?>
<?php unset($__componentOriginal43d0157cd0e4489a7071d7d85ee34682); ?>
<?php endif; ?><?php /**PATH C:\Users\ESTAGIO\Herd\reshoppingpap\resources\views/categorias/show.blade.php ENDPATH**/ ?>